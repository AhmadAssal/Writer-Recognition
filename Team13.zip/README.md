# Writer-Recognition
## This is a writer identification system done using LBP to identify the writer of a given piece of text
____________________________________________________________________

### This Project is trained on the IAM dataset 


To run this project

Either: 
copy the main file into a directory that has a subdirectory called "data"
then use the following command in the terminal "python3 main.py"

So:
folder:
    main.py
    data: 0
               1
               2




OR:
run it wherever but specify the parent directory of "data"
using this command python3 main.py your_directory_path


